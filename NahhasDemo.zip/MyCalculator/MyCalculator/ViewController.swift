/*
 (String ?)الاسترينق مع ؟ معناها خياري (optinal)
 ف عشان نشيل كلمة اوبشينال لازم نحط علامة !
 */
import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var display: UILabel!
    
    var userIsInTheMiddleOfTyping = false

    @IBAction func number0(_ sender: UIButton) {
        let digit = sender.currentTitle!
        if userIsInTheMiddleOfTyping{
        let textCurrentlyDisplay = display.text!
        display.text = textCurrentlyDisplay + digit
        }else {
            display.text = digit
            userIsInTheMiddleOfTyping = true
        }
        
        
        
        
       //print("\(String(describing: digit)) was tuched")
    }
    
    var displayValue: Double {
        get{  // الفكرا هنا انو القت بتحفظ الرمز الي هو استرنق على انو دبل
            return Double(display.text!)!
        }
        set{//الست هنا بترجع الدبل لسترنق 
            display.text = String(newValue)
            
        }
    }
    
    private var brain = CalculatorBrain() //سويت ابجكت من الايتراكت الي اسمو كالكوليتر برين
    
    
    @IBAction func performOperation(_ sender: UIButton) {
        if userIsInTheMiddleOfTyping {
            brain.setOperand(displayValue)
            userIsInTheMiddleOfTyping = false

        }
        
        //let value = display.text!
        if let mathematicalSymbol = sender.currentTitle {
            brain.performOperation(mathematicalSymbol)
            
        }
        if let result = brain.result{
            displayValue = result
        }
        
        
    }
    
    

}

