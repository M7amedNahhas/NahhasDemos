//
//  CalculatorBrain.swift
//  MyCalculator
//
//  Created by m7amednahhas on 10/12/1438 AH.
//  Copyright © 1438 m7amednahhas. All rights reserved.
//

import Foundation


struct CalculatorBrain {//اليفرق بين الكلاس و الستراكت انو الكلاس يمديك تستخدم معاه الانهرتنز بس الاستراكت لا و الاستراكت اتوماتك يديك خاصية الانشالايز عكس الكلاس
    
    private var accumulator: Double? // السبب الي خلانا نحطو برايفت عشان بس بنستخدمو في الاستراكت دا 
    
    private enum Operation{
        case constant(Double)
        case unaryOperation((Double) -> Double)
        case bainaryOperation((Double,Double) -> Double)
        case equals
        
        
    }
    
    private var operations: Dictionary<String,Operation> =  //الدكشنري حتختصر علينا شغل السويتش و الكيس
    [
        "π" : Operation.constant(Double.pi),
        "e" : Operation.constant(M_E),
        "√" : Operation.unaryOperation(sqrt) ,
        "cos" : Operation.unaryOperation(cos),
        "±" : Operation.unaryOperation({-$0}),
        "×" : Operation.bainaryOperation({$0 * $1}),
        "÷" : Operation.bainaryOperation({$0 / $1}),
        "+" : Operation.bainaryOperation({$0 + $1}),
        "-" : Operation.bainaryOperation({$0 - $1}),
        "=" : Operation.equals
    ]
    mutating func performOperation(_ symbol: String){
        if let operation = operations[symbol]{
            switch operation {
            case .constant(let value):
                accumulator = value
                
            case .unaryOperation(let f):
                if accumulator != nil{
                    accumulator = f(accumulator!)
                }
            case .bainaryOperation(let f):
                if accumulator != nil{
                    pendingBinaryOperation = PendingBinaryOperation(f: f, firstOperand: accumulator!)
                    accumulator = nil
                }
                
            case .equals:
                performPendingBinaryOperation()
                
                
            }
            
            
        }
      
    }
    private mutating func performPendingBinaryOperation(){
        if pendingBinaryOperation != nil && accumulator != nil {
            accumulator = pendingBinaryOperation!.perform(with: accumulator!)
            pendingBinaryOperation = nil
        }
    }
    private var pendingBinaryOperation: PendingBinaryOperation?
    
    private struct PendingBinaryOperation{
        let f: (Double,Double) ->Double
        let firstOperand: Double
        func perform(with secondOperand: Double) -> Double{
            return f(firstOperand, secondOperand)
            
        }
        
    }
    
    
    mutating func setOperand(_ operand: Double){//مويتاتينق الي في الاول يعني اني اقول للسوفت انو يسمحلها انو يغير القيمة تبعتو
        accumulator = operand
        
    }
    
    var result: Double?{
        return accumulator
            
        
      
    }
    
    
}
