//
//  ViewController.swift
//  XOgame
//
//  Created by m7amednahhas on 10/11/1438 AH.
//  Copyright © 1438 m7amednahhas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var player = 1 //cross
    var gameState = [0,0,0,0,0,0,0,0,0]
    
    let gameWin = [[1,2,3], [4,5,6], [7,8,9,], [1,4,7], [2,5,8], [3,6,9], [3,5,7], [1,5,9]]
    var gameIsActive = true
    
    @IBOutlet weak var lable: UILabel!
    
    
    @IBAction func acton(_ sender: UIButton) {
        if (gameState[sender.tag-1] == 0 && gameIsActive == true){
            
            gameState[sender.tag-1] = player
            
            if (player == 1) {
                sender.setImage(UIImage(named:"Cross.png"), for: UIControlState())
                player = 2
                
            }else {
                sender.setImage(UIImage(named:"Nought.png"), for: UIControlState())
                player = 1
                
            }
            for combination in gameWin{
                if gameState[combination[0]] != 0 && gameState[combination[0]] == gameState[combination[1]] && gameState[combination[1]] == gameState[combination[2]]{
                    
                    gameIsActive = false
                    if gameState[combination[0]] == 1{
                        lable.text = "cross has won!"
                    }else{
                        lable.text = "nought has won!"
                    }
                    plaiAgainBt.isHidden = false
                    lable.isHidden = false
                
                    
                }
            }
        }
        
    }
    
    @IBOutlet weak var plaiAgainBt: UIButton!
    
    @IBAction func playAgain(_ sender: UIButton) {
        
        gameState = [0,0,0,0,0,0,0,0,0]
        gameIsActive = true
        player = 1
        
        plaiAgainBt.isHidden = true
        lable.isHidden = true
        
        
        for i in 1...9{
            let bt = view.viewWithTag(i) as! UIButton
            bt.setImage(nil, for: UIControlState())
        }
        
        
        
    }
    
    
}

